module.exports={
    getNews(){
        let data= {
            con: [
                {
                    "desc": "BELLE/百丽专柜白色人造革/纺织品/牛皮革女休闲.",
                    "pic": "http://39.107.245.176/images/cart/100913586_01_m.jpg",
                    "color": "白色", "size": "39", "express": "百丽优购", "price": "358"
                },
                {
                    "desc": "BELLE/百丽2019秋新商场同款猪巴戈/织物/复合..",
                    "pic": "http://39.107.245.176/images/cart/101292193_01_m.jpg",
                    "color": "粉/黑/灰", "size": "40", "express": "百丽优购", "price": "549"
                },
                {
                    "desc": "PENZU字母短靴",
                    "pic": "http://39.107.245.176/images/cart/101013931_01_m.jpg",
                    "color": "白色", "size": "39", "express": "百丽优购", "price": "223"
                },
                {
                    "desc": "SKAP/圣伽步2018春夏专柜同款黑色牛皮商务男...",
                    "pic": "http://39.107.245.176/images/cart/100913586_01_m.jpg",
                    "color": "黑色", "size": "40", "express": "百丽优购", "price": "470"
                },
            ],
            foot: [
                {"totalprice": "1600", "mit": "303", "tnum": "4"},
            ]
        }
        return data;
    }
}
