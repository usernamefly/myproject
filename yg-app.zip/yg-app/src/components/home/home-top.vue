<template>
    <div class="home-top-con">
        <span></span>
    </div>
</template>

<script>
    export default {
        name: "home-top",
    }
</script>

<style scoped>

</style>
