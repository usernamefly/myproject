<template>
    <div class="bai-spl">
        <p>4685人关注  关注</p>
    </div>
</template>

<script>
    export default {
        name: "bai-splid"
    }
</script>

<style scoped>
.bai-spl{
    width: 100%;
    background-image: url("../../assets/images/baili/1558519178433.png");
    background-size: 100%;
    height: 1.3rem;
    background-repeat: no-repeat;
    margin-top: 0.45rem;
    font-size: 0.14rem;
    color: white;
    padding:1rem 0.1rem 0.1rem 2.5rem;
    font-weight: 500;
    box-sizing: border-box;
}
.bai-spl>p{
    text-shadow: gray 1px 1px 1px;
}
</style>
