export const BASEURL = 'http://39.107.245.176:3000'
