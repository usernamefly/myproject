module.exports = {
    getNews(){
        let data = {
            "heads":["../../assets/images/home/1547706860219.png",
                "../../assets/images/home/1547706864808.png",
            "../../assets/images/home/1547706869505.png",
            "../../assets/images/home/1547706876310.png"],
            "middle":["../../assets/images/home/1572672808483.jpg","../../assets/images/home/1572672817784.jpg",
                "../../assets/images/home/1572672826415.jpg","../../assets/images/home/1572672835674.gif"],
            "middle_bot":["../../assets/images/home/1572672967928.jpg",
                "../../assets/images/home/1572672978658.jpg","../../assets/images/home/1572672988148.jpg"],
            "rename":"热门分类",
            "reimg":["../../assets/images/home/1568599199800.jpg","../../assets/images/home/1568599208206.jpg",
                "../../assets/images/home/1568599215890.jpg","../../assets/images/home/1568599229435.jpg",
                "../../assets/images/home/1568599343367.jpg","../../assets/images/home/1568599351453.jpg",
                "../../assets/images/home/1568599360680.jpg","../../assets/images/home/1568599368269.jpg"],
            "footer":[
                {pic:"../../assets/images/home/toolbar_home_selected.png",pic_name:"首页"},
                {pic:"../../assets/images/home/toolbar_categories_normal.png",pic_name:"分类"},
                {pic:"../../assets/images/home/toolbar_discover_normal.png",pic_name:"发现"},
                {pic:"../../assets/images/home/toolbar_shopcar_normal.png",pic_name:"购物车"},
                {pic:"../../assets/images/home/toolbar_personal_normal.png",pic_name:"我的"}
            ]
        }
        return data;
    }
};
